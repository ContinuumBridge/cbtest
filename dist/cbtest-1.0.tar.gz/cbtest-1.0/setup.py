from distutils.core import setup
setup(name='cbtest',
      version='1.0',
      py_modules=['cbtest'],
      )
